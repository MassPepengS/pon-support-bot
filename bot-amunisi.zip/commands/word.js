const fs = require('fs');

module.exports = {
    name: 'word',
    async executePrefix(message, args, SETTINGS_FILE, settings, isRealAdmin, isCustomAdmin) {
        
        // Proteksi
        if (!isRealAdmin && !isCustomAdmin) {
            return message.reply("❌ You don't have permission to use this command.");
        }

        if (args.length === 0) {
            return message.reply("ℹ️ **Usage:**\n`pon word add [word]` - Add a word to the filter\n`pon word rmv [word]` - Remove a word from the filter\n`pon word list` - View filtered words");
        }

        const action = args[0].toLowerCase();
        const wordInput = args.slice(1).join(' ').toLowerCase();
        const guildId = message.guild.id;

        if (!settings[guildId].badWords) settings[guildId].badWords = [];

        // COMMAND: ADD
        if (action === 'add' || action === 'crt') {
            if (!wordInput) return message.reply("❌ Please specify a word to add.");
            
            if (settings[guildId].badWords.includes(wordInput)) {
                return message.reply("⚠️ That word is already in the filter list.");
            }
            
            settings[guildId].badWords.push(wordInput);
            fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2));
            return message.reply(`✅ Successfully added **"${wordInput}"** to the filter list.`);
        }

        // COMMAND: REMOVE
        if (action === 'rmv' || action === 'del') {
            if (!wordInput) return message.reply("❌ Please specify a word to remove.");
            
            const index = settings[guildId].badWords.indexOf(wordInput);
            if (index === -1) {
                return message.reply("⚠️ That word is not in the filter list.");
            }
            
            // Hapus kata dari array
            settings[guildId].badWords.splice(index, 1);
            fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2));
            
            // INI BAGIAN YANG HILANG: Mengirim konfirmasi sukses!
            return message.reply(`✅ Successfully removed **"${wordInput}"** from the filter list.`);
        }

        // COMMAND: LIST
        if (action === 'list') {
            const list = settings[guildId].badWords;
            if (!list || list.length === 0) {
                return message.reply("📝 The filter list is currently empty.");
            }
            return message.reply(`📝 **Filtered Words:**\n\`${list.join(', ')}\``);
        }

        // Jika salah ketik action
        return message.reply("❌ Invalid action. Please use `add`, `rmv`, or `list`.");
    }
};
