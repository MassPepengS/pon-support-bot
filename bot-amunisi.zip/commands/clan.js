const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const profileFile = path.join(__dirname, '../profiles.json');

module.exports = {
    name: 'clan',
    description: 'Set your in-game Clan for your RPG profile.',

    async executePrefix(message, args) {
        const clanName = args.join(' ').trim();
        if (!clanName) return message.reply('❌ **Usage:** `pon clan [your_clan_name]`');

        const guildId = message.guild.id;
        const userId = message.author.id;
        
        let db = fs.existsSync(profileFile) ? JSON.parse(fs.readFileSync(profileFile, 'utf8')) : {};
        if (!db[guildId]) db[guildId] = {};
        if (!db[guildId][userId]) db[guildId][userId] = { xp: 0, level: 1, activeTitle: "New Explorer", badges: ['🌟'] };

        db[guildId][userId].clan = clanName;
        fs.writeFileSync(profileFile, JSON.stringify(db, null, 4));

        return message.reply(`✅ **Clan Updated!** Your profile now shows your clan as: \`${clanName}\``);
    },

    data: new SlashCommandBuilder()
        .setName('clan')
        .setDescription('Set your in-game Clan.')
        .addStringOption(opt => opt.setName('name').setDescription('Your in-game clan name').setRequired(true)),

    async executeSlash(interaction) {
        const clanName = interaction.options.getString('name');
        const guildId = interaction.guild.id;
        const userId = interaction.user.id;
        
        let db = fs.existsSync(profileFile) ? JSON.parse(fs.readFileSync(profileFile, 'utf8')) : {};
        if (!db[guildId]) db[guildId] = {};
        if (!db[guildId][userId]) db[guildId][userId] = { xp: 0, level: 1, activeTitle: "New Explorer", badges: ['🌟'] };

        db[guildId][userId].clan = clanName;
        fs.writeFileSync(profileFile, JSON.stringify(db, null, 4));

        return interaction.reply({ content: `✅ **Clan Updated!** Your profile now shows your clan as: \`${clanName}\``, ephemeral: true });
    }
};
