const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const profileFile = path.join(__dirname, '../profiles.json');

module.exports = {
    name: 'delalbum',
    description: 'Remove the custom album image from your RPG profile.',

    // ==========================================
    // 1. PREFIX COMMAND (pon delalbum)
    // ==========================================
    async executePrefix(message, args) {
        const guildId = message.guild.id;
        const userId = message.author.id;
        
        let db = fs.existsSync(profileFile) ? JSON.parse(fs.readFileSync(profileFile, 'utf8')) : {};
        if (!db[guildId]) db[guildId] = {};
        if (!db[guildId][userId]) {
            db[guildId][userId] = { xp: 0, level: 1, activeTitle: "New Explorer", badges: ['🌟'], gamertag: null, clan: null, album: null };
        }

        // Menghapus data album (mengubahnya kembali menjadi null)
        db[guildId][userId].album = null;
        fs.writeFileSync(profileFile, JSON.stringify(db, null, 4));

        return message.reply('✅ **Album Removed!** Your profile image has been successfully cleared.');
    },

    // ==========================================
    // 2. SLASH COMMAND (/delalbum)
    // ==========================================
    data: new SlashCommandBuilder()
        .setName('delalbum')
        .setDescription('Remove the custom album image from your RPG profile.'),

    async executeSlash(interaction) {
        const guildId = interaction.guild.id;
        const userId = interaction.user.id;
        
        let db = fs.existsSync(profileFile) ? JSON.parse(fs.readFileSync(profileFile, 'utf8')) : {};
        if (!db[guildId]) db[guildId] = {};
        if (!db[guildId][userId]) {
            db[guildId][userId] = { xp: 0, level: 1, activeTitle: "New Explorer", badges: ['🌟'], gamertag: null, clan: null, album: null };
        }

        // Menghapus data album (mengubahnya kembali menjadi null)
        db[guildId][userId].album = null;
        fs.writeFileSync(profileFile, JSON.stringify(db, null, 4));

        return interaction.reply({ content: '✅ **Album Removed!** Your profile image has been successfully cleared.', ephemeral: true });
    }
};
