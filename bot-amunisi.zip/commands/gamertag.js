const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const profileFile = path.join(__dirname, '../profiles.json');

module.exports = {
    name: 'gamertag',
    description: 'Set your in-game Gamertag for your RPG profile.',

    async executePrefix(message, args) {
        const tag = args.join(' ').trim();
        if (!tag) return message.reply('❌ **Usage:** `pon gamertag [your_ingame_name]`');

        const guildId = message.guild.id;
        const userId = message.author.id;
        
        let db = fs.existsSync(profileFile) ? JSON.parse(fs.readFileSync(profileFile, 'utf8')) : {};
        if (!db[guildId]) db[guildId] = {};
        if (!db[guildId][userId]) db[guildId][userId] = { xp: 0, level: 1, activeTitle: "New Explorer", badges: ['🌟'] };

        db[guildId][userId].gamertag = tag;
        fs.writeFileSync(profileFile, JSON.stringify(db, null, 4));

        return message.reply(`✅ **Gamertag Updated!** Your profile now shows your gamertag as: \`${tag}\``);
    },

    data: new SlashCommandBuilder()
        .setName('gamertag')
        .setDescription('Set your in-game Gamertag.')
        .addStringOption(opt => opt.setName('name').setDescription('Your in-game name').setRequired(true)),

    async executeSlash(interaction) {
        const tag = interaction.options.getString('name');
        const guildId = interaction.guild.id;
        const userId = interaction.user.id;
        
        let db = fs.existsSync(profileFile) ? JSON.parse(fs.readFileSync(profileFile, 'utf8')) : {};
        if (!db[guildId]) db[guildId] = {};
        if (!db[guildId][userId]) db[guildId][userId] = { xp: 0, level: 1, activeTitle: "New Explorer", badges: ['🌟'] };

        db[guildId][userId].gamertag = tag;
        fs.writeFileSync(profileFile, JSON.stringify(db, null, 4));

        return interaction.reply({ content: `✅ **Gamertag Updated!** Your profile now shows your gamertag as: \`${tag}\``, ephemeral: true });
    }
};
