const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const profileFile = path.join(__dirname, '../profiles.json');

module.exports = {
    name: 'likes',
    description: 'Give a like to another player\'s RPG profile.',

    async executePrefix(message, args) {
        let targetUser = message.mentions.users.first();
        if (!targetUser && args[0]) {
            targetUser = await message.client.users.fetch(args[0]).catch(() => null);
        }
        if (!targetUser) return message.reply('❌ **Usage:** `pon likes [@user/ID]`');
        if (targetUser.bot) return message.reply('❌ You cannot like a bot profile.');
        if (targetUser.id === message.author.id) return message.reply('❌ You cannot like your own profile!');

        const guildId = message.guild.id;
        let db = fs.existsSync(profileFile) ? JSON.parse(fs.readFileSync(profileFile, 'utf8')) : {};
        if (!db[guildId]) db[guildId] = {};
        if (!db[guildId][targetUser.id]) {
            db[guildId][targetUser.id] = { xp: 0, level: 1, titles: [], badges: ['🌟'], activeTitle: "New Explorer", gamertag: null, clan: null, album: null, likes: [], charisma: 0 };
        }
        if (!db[guildId][targetUser.id].likes) db[guildId][targetUser.id].likes = [];

        if (db[guildId][targetUser.id].likes.includes(message.author.id)) {
            return message.reply(`⚠️ You have already liked **${targetUser.username}**'s profile!`);
        }

        db[guildId][targetUser.id].likes.push(message.author.id);
        fs.writeFileSync(profileFile, JSON.stringify(db, null, 4));

        return message.reply(`✅ Successfully given a like to **${targetUser.username}**'s profile!`);
    },

    data: new SlashCommandBuilder()
        .setName('likes')
        .setDescription('Give a like to another player\'s RPG profile.')
        .addUserOption(opt => opt.setName('user').setDescription('Select a player').setRequired(true)),

    async executeSlash(interaction) {
        const targetUser = interaction.options.getUser('user');
        if (targetUser.bot) return interaction.reply({ content: '❌ You cannot like a bot profile.', ephemeral: true });
        if (targetUser.id === interaction.user.id) return interaction.reply({ content: '❌ You cannot like your own profile!', ephemeral: true });

        const guildId = interaction.guild.id;
        let db = fs.existsSync(profileFile) ? JSON.parse(fs.readFileSync(profileFile, 'utf8')) : {};
        if (!db[guildId]) db[guildId] = {};
        if (!db[guildId][targetUser.id]) {
            db[guildId][targetUser.id] = { xp: 0, level: 1, titles: [], badges: ['🌟'], activeTitle: "New Explorer", gamertag: null, clan: null, album: null, likes: [], charisma: 0 };
        }
        if (!db[guildId][targetUser.id].likes) db[guildId][targetUser.id].likes = [];

        if (db[guildId][targetUser.id].likes.includes(interaction.user.id)) {
            return interaction.reply({ content: `⚠️ You have already liked **${targetUser.username}**'s profile!`, ephemeral: true });
        }

        db[guildId][targetUser.id].likes.push(interaction.user.id);
        fs.writeFileSync(profileFile, JSON.stringify(db, null, 4));

        return interaction.reply({ content: `✅ Successfully given a like to **${targetUser.username}**'s profile!`, ephemeral: true });
    }
};
