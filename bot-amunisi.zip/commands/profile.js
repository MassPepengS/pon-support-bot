const { EmbedBuilder, SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');

const profileFile = path.join(__dirname, '../profiles.json');

function checkProfileDB() {
    if (!fs.existsSync(profileFile)) {
        fs.writeFileSync(profileFile, JSON.stringify({}, null, 4));
    }
    return JSON.parse(fs.readFileSync(profileFile, 'utf8'));
}

function createProgressBar(current, max, size = 15) {
    const progress = Math.round((current / max) * size);
    const safeProgress = Math.min(Math.max(progress, 0), size);
    const emptyProgress = size - safeProgress;
    return `[${'■'.repeat(safeProgress)}${'□'.repeat(emptyProgress)}]`;
}

module.exports = {
    name: 'profile',
    description: 'View your or another player\'s RPG Profile.',

    async executePrefix(message, args) {
        let targetUser = message.mentions.users.first();
        if (!targetUser && args[0]) {
            targetUser = await message.client.users.fetch(args[0]).catch(() => null);
        }
        if (!targetUser) targetUser = message.author;
        
        if (targetUser.bot) return message.reply({ content: '❌ Bots do not have an RPG profile.' });

        const guildId = message.guild.id;
        const db = checkProfileDB();

        if (!db[guildId]) db[guildId] = {};
        if (!db[guildId][targetUser.id]) {
            db[guildId][targetUser.id] = { xp: 0, level: 1, titles: [], badges: ['🌟'], activeTitle: "New Explorer", gamertag: null, clan: null, album: null, likes: [], charisma: 0 };
            fs.writeFileSync(profileFile, JSON.stringify(db, null, 4));
        }

        const userData = db[guildId][targetUser.id];
        
        if (!userData.likes) userData.likes = [];
        if (!userData.charisma) userData.charisma = 0;

        const currentLevel = userData.level || 1;
        const currentXP = userData.xp || 0;
        const requiredXP = currentLevel * currentLevel * 100; 
        const previousLevelXP = (currentLevel - 1) * (currentLevel - 1) * 100;
        
        const xpInCurrentLevel = currentXP - previousLevelXP;
        const xpNeededForLevelUp = requiredXP - previousLevelXP;
        const progressBar = createProgressBar(xpInCurrentLevel, xpNeededForLevelUp, 15);

        const divider = '─────────────────────';
        let desc = `**${userData.activeTitle || 'New Explorer'}**\n${divider}\n`;
        
        if (userData.badges && userData.badges.length > 0) {
            desc += `${userData.badges.join(' ')}\n${divider}\n`;
        }

        desc += `**PROGRESS:**\nLevel: **${currentLevel}**\n${xpInCurrentLevel} / ${xpNeededForLevelUp} XP\n\`${progressBar}\`\n${divider}\n`;
        
        // Desain User Info Rapat untuk Mobile & Desktop
        const userTag = userData.gamertag || '*Not set*';
        const clanTag = userData.clan || '*Not set*';
        const likesCount = userData.likes.length;
        const charismaCount = userData.charisma;

        desc += `**USER INFO:**\n`;
        desc += `<:user:1509262449394716803> ${userTag}\n`;
        desc += `<:clan:1509262421423034549> ${clanTag}\n\n`;
        desc += `<:like:1509251461719261214> **${likesCount}**   |   <:charisma:1509251389321122064> **${charismaCount}**`;

        const embed = new EmbedBuilder()
            .setColor('#2F3136')
            .setAuthor({ name: `${targetUser.username}'s Profile`, iconURL: targetUser.displayAvatarURL({ dynamic: true }) })
            .setThumbnail(targetUser.displayAvatarURL({ dynamic: true, size: 256 }))
            .setDescription(desc);

        if (userData.album) embed.setImage(userData.album);

        const componentsArray = [];
        
        // Logika Sakelar: Tombol Like HANYA muncul jika melihat profil orang lain
        if (targetUser.id !== message.author.id) {
            const likeBtn = new ButtonBuilder()
                .setCustomId(`like_profile_${targetUser.id}`)
                .setLabel('Like / Unlike')
                .setStyle(ButtonStyle.Primary)
                .setEmoji('<:like:1509251461719261214>');

            componentsArray.push(new ActionRowBuilder().addComponents(likeBtn));
        }

        return message.reply({ embeds: [embed], components: componentsArray });
    },

    data: new SlashCommandBuilder()
        .setName('profile')
        .setDescription('View your or another player\'s RPG Profile.')
        .addUserOption(option => option.setName('user').setDescription('Select a user (Optional)').setRequired(false)),

    async executeSlash(interaction) {
        const targetUser = interaction.options.getUser('user') || interaction.user;
        if (targetUser.bot) return interaction.reply({ content: '❌ Bots do not have an RPG profile.', ephemeral: true });

        const guildId = interaction.guild.id;
        const db = checkProfileDB();

        if (!db[guildId]) db[guildId] = {};
        if (!db[guildId][targetUser.id]) {
            db[guildId][targetUser.id] = { xp: 0, level: 1, titles: [], badges: ['🌟'], activeTitle: "New Explorer", gamertag: null, clan: null, album: null, likes: [], charisma: 0 };
            fs.writeFileSync(profileFile, JSON.stringify(db, null, 4));
        }

        const userData = db[guildId][targetUser.id];
        
        if (!userData.likes) userData.likes = [];
        if (!userData.charisma) userData.charisma = 0;
        
        const currentLevel = userData.level || 1;
        const currentXP = userData.xp || 0;
        const requiredXP = currentLevel * currentLevel * 100;
        const previousLevelXP = (currentLevel - 1) * (currentLevel - 1) * 100;
        
        const xpInCurrentLevel = currentXP - previousLevelXP;
        const xpNeededForLevelUp = requiredXP - previousLevelXP;
        const progressBar = createProgressBar(xpInCurrentLevel, xpNeededForLevelUp, 15);

        const divider = '─────────────────────';
        let desc = `**${userData.activeTitle || 'New Explorer'}**\n${divider}\n`;
        
        if (userData.badges && userData.badges.length > 0) {
            desc += `${userData.badges.join(' ')}\n${divider}\n`;
        }

        desc += `**PROGRESS:**\nLevel: **${currentLevel}**\n${xpInCurrentLevel} / ${xpNeededForLevelUp} XP\n\`${progressBar}\`\n${divider}\n`;

        // Desain User Info Rapat untuk Mobile & Desktop
        const userTag = userData.gamertag || '*Not set*';
        const clanTag = userData.clan || '*Not set*';
        const likesCount = userData.likes.length;
        const charismaCount = userData.charisma;

        desc += `**USER INFO:**\n`;
        desc += `<:user:1509262449394716803> ${userTag}\n`;
        desc += `<:clan:1509262421423034549> ${clanTag}\n\n`;
        desc += `<:like:1509251461719261214> **${likesCount}**   |   <:charisma:1509251389321122064> **${charismaCount}**`;

        const embed = new EmbedBuilder()
            .setColor('#2F3136')
            .setAuthor({ name: `${targetUser.username}'s Profile`, iconURL: targetUser.displayAvatarURL({ dynamic: true }) })
            .setThumbnail(targetUser.displayAvatarURL({ dynamic: true, size: 256 }))
            .setDescription(desc);

        if (userData.album) embed.setImage(userData.album);

        const componentsArray = [];

        // Logika Sakelar: Tombol Like HANYA muncul jika melihat profil orang lain
        if (targetUser.id !== interaction.user.id) {
            const likeBtn = new ButtonBuilder()
                .setCustomId(`like_profile_${targetUser.id}`)
                .setLabel('Like / Unlike')
                .setStyle(ButtonStyle.Primary)
                .setEmoji('<:like:1509251461719261214>');

            componentsArray.push(new ActionRowBuilder().addComponents(likeBtn));
        }

        return interaction.reply({ embeds: [embed], components: componentsArray });
    }
};
