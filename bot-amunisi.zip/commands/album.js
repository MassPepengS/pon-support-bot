const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const profileFile = path.join(__dirname, '../profiles.json');

module.exports = {
    name: 'album',
    description: 'Set a custom image/screenshot for your profile album.',

    async executePrefix(message, args) {
        const attachment = message.attachments.first();
        if (!attachment) {
            return message.reply('❌ **Usage:** `pon album`\n*(You must attach an image to your message!)*');
        }

        const guildId = message.guild.id;
        const userId = message.author.id;
        
        let db = fs.existsSync(profileFile) ? JSON.parse(fs.readFileSync(profileFile, 'utf8')) : {};
        if (!db[guildId]) db[guildId] = {};
        if (!db[guildId][userId]) db[guildId][userId] = { xp: 0, level: 1, activeTitle: "New Explorer", badges: ['🌟'] };

        db[guildId][userId].album = attachment.url;
        fs.writeFileSync(profileFile, JSON.stringify(db, null, 4));

        return message.reply(`✅ **Album Updated!** Your custom image has been mounted to your profile.`);
    },

    data: new SlashCommandBuilder()
        .setName('album')
        .setDescription('Set a custom image for your profile album.')
        .addAttachmentOption(opt => opt.setName('image').setDescription('Upload an image/screenshot').setRequired(true)),

    async executeSlash(interaction) {
        const attachment = interaction.options.getAttachment('image');
        const guildId = interaction.guild.id;
        const userId = interaction.user.id;
        
        let db = fs.existsSync(profileFile) ? JSON.parse(fs.readFileSync(profileFile, 'utf8')) : {};
        if (!db[guildId]) db[guildId] = {};
        if (!db[guildId][userId]) db[guildId][userId] = { xp: 0, level: 1, activeTitle: "New Explorer", badges: ['🌟'] };

        db[guildId][userId].album = attachment.url;
        fs.writeFileSync(profileFile, JSON.stringify(db, null, 4));

        return interaction.reply({ content: `✅ **Album Updated!** Your custom image has been mounted to your profile.`, ephemeral: true });
    }
};
