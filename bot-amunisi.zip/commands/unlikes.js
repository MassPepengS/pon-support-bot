const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const profileFile = path.join(__dirname, '../profiles.json');

module.exports = {
    name: 'unlikes',
    description: 'Remove your like from another player\'s RPG profile.',

    async executePrefix(message, args) {
        let targetUser = message.mentions.users.first();
        if (!targetUser && args[0]) {
            targetUser = await message.client.users.fetch(args[0]).catch(() => null);
        }
        if (!targetUser) return message.reply('❌ **Usage:** `pon unlikes [@user/ID]`');

        const guildId = message.guild.id;
        let db = fs.existsSync(profileFile) ? JSON.parse(fs.readFileSync(profileFile, 'utf8')) : {};
        
        if (!db[guildId] || !db[guildId][targetUser.id] || !db[guildId][targetUser.id].likes) {
            return message.reply(`⚠️ You haven't liked **${targetUser.username}**'s profile yet!`);
        }

        const index = db[guildId][targetUser.id].likes.indexOf(message.author.id);
        if (index === -1) {
            return message.reply(`⚠️ You haven't liked **${targetUser.username}**'s profile yet!`);
        }

        db[guildId][targetUser.id].likes.splice(index, 1);
        fs.writeFileSync(profileFile, JSON.stringify(db, null, 4));

        return message.reply(`✅ You have successfully removed your like from **${targetUser.username}**'s profile.`);
    },

    data: new SlashCommandBuilder()
        .setName('unlikes')
        .setDescription('Remove your like from another player\'s RPG profile.')
        .addUserOption(opt => opt.setName('user').setDescription('Select a player').setRequired(true)),

    async executeSlash(interaction) {
        const targetUser = interaction.options.getUser('user');
        const guildId = interaction.guild.id;
        
        let db = fs.existsSync(profileFile) ? JSON.parse(fs.readFileSync(profileFile, 'utf8')) : {};
        if (!db[guildId] || !db[guildId][targetUser.id] || !db[guildId][targetUser.id].likes) {
            return interaction.reply({ content: `⚠️ You haven't liked **${targetUser.username}**'s profile yet!`, ephemeral: true });
        }

        const index = db[guildId][targetUser.id].likes.indexOf(interaction.user.id);
        if (index === -1) {
            return interaction.reply({ content: `⚠️ You haven't liked **${targetUser.username}**'s profile yet!`, ephemeral: true });
        }

        db[guildId][targetUser.id].likes.splice(index, 1);
        fs.writeFileSync(profileFile, JSON.stringify(db, null, 4));

        return interaction.reply({ content: `✅ You have successfully removed your like from **${targetUser.username}**'s profile.`, ephemeral: true });
    }
};
