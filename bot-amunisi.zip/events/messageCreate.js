const { Events, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

// Sistem Cooldown Anti-Spam EXP (Tersimpan di RAM, bukan di file)
const xpCooldowns = new Set();
const profileFile = path.join(__dirname, '../profiles.json');

module.exports = {
    name: Events.MessageCreate,
    async execute(message, client) {
        if (message.author.bot || !message.guild) return;

        // ==========================================
        // 1. MESIN PENGECEK CAPTCHA 
        // ==========================================
        if (message.channel.name.startsWith('verify-')) {
            if (!client.captchaCodes) client.captchaCodes = new Map();
            const expectedCode = client.captchaCodes.get(message.author.id);

            if (expectedCode && message.channel.topic === message.author.id) {
                if (message.content === expectedCode) {
                    const settings = client.checkDatabase(message.guild.id);
                    const unvRole = message.guild.roles.cache.get(settings[message.guild.id]?.unverifiedRoleId);
                    const verRole = message.guild.roles.cache.get(settings[message.guild.id]?.verifiedRoleId);

                    if (unvRole) await message.member.roles.remove(unvRole).catch(()=>{});
                    message.reply('✅ **VERIFICATION SUCCESSFUL!** Server access will open in 1 minute. This channel will be destroyed at the same time, please wait...').catch(()=>{});
                    client.captchaCodes.delete(message.author.id);

                    setTimeout(async () => {
                        if (verRole) await message.member.roles.add(verRole).catch(()=>{});
                        await message.channel.delete().catch(()=>{});
                    }, 60000);
                } else {
                    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
                    let newCode = '';
                    for (let i = 0; i < 6; i++) {
                        newCode += characters.charAt(Math.floor(Math.random() * characters.length));
                    }
                    client.captchaCodes.set(message.author.id, newCode);
                    const imageUrl = `https://dummyimage.com/300x100/2F3136/ffffff.png&text=${newCode}`;

                    const embed = new EmbedBuilder()
                        .setColor('#ED4245')
                        .setTitle('❌ CAPTCHA WRONG!')
                        .setDescription('The code doesnt match! Please try again with the new code show in the image below:\n*(Make sure the case is correct)*')
                        .setImage(imageUrl);

                    message.reply({ embeds: [embed] }).catch(()=>{});
                }
                return; 
            }
        }

        // ==========================================
        // 2. SISTEM AUTOMOD & RADAR KEAMANAN
        // ==========================================
        try {
            const guildId = message.guild.id;
            const settings = client.checkDatabase(guildId);
            const contentLower = message.content.toLowerCase();
            const contentRaw = message.content;

            const badWords = settings[guildId].badWords || [];
            const allowedLinkChannels = settings[guildId].linkAllowedChannels || [];
            const isLinkAllowedChannel = allowedLinkChannels.includes(message.channel.id);
            const isCommand = contentLower.startsWith(`${client.PREFIX.toLowerCase()} `);
            const hasAdminPerm = message.member?.permissions?.has(PermissionFlagsBits.ManageMessages) || false;
            let isViolating = false;

            const sendAutoModLog = async (reason, originalContent) => {
                try {
                    let logChannelId = settings[guildId].modLogChannelId;
                    let logChannel = null;
                    if (logChannelId) {
                        logChannel = message.guild.channels.cache.get(logChannelId) || await message.guild.channels.fetch(logChannelId).catch(()=>null);
                    } else {
                        logChannel = message.guild.channels.cache.find(c => c.name.includes('mod'));
                    }
                    if (!logChannel) return;

                    let caseId = "000000";
                    try {
                        let db = JSON.parse(fs.readFileSync(client.SETTINGS_FILE, 'utf8'));
                        if (!db[guildId]) db[guildId] = {};
                        db[guildId].caseCount = (db[guildId].caseCount || 0) + 1;
                        fs.writeFileSync(client.SETTINGS_FILE, JSON.stringify(db, null, 2));
                        caseId = db[guildId].caseCount.toString().padStart(6, '0');
                    } catch (err) { caseId = "ERR" + Math.floor(Math.random() * 1000); }

                    const safeContent = originalContent.length > 1000 ? originalContent.substring(0, 1000) + "..." : originalContent;
                    const logEmbed = new EmbedBuilder().setColor('#ED4245').setAuthor({ name: `AutoMod | ${message.author.username}` }).setDescription(`**USER**\n<@${message.author.id}> | ${message.author.username}\n**STAFF**\nAutoMod\n**REASON**\n${reason}\n**MESSAGE CONTENT**\n${safeContent}\n\n**CASE ID:** ${caseId}`).setTimestamp();
                    await logChannel.send({ embeds: [logEmbed] }).catch(async () => {});
                } catch (error) {}
            };

            // Radar Anti-Invite
            if (!isCommand && !hasAdminPerm) {
                const inviteRegex = /(https?:\/\/)?(www\.)?(discord\.(gg|io|me|li)|discordapp\.com\/invite|discord\.com\/invite)\/[a-zA-Z0-9]+/i;
                if (inviteRegex.test(contentRaw) && settings[guildId].antiInvite === true) {
                    isViolating = true;
                    await message.delete().catch(()=>{});
                    sendAutoModLog('🛡️ ANTI-INVITE: Blocked Server Link', contentRaw);
                    message.channel.send(`⚠️ <@${message.author.id}>, **Action Blocked!** Sharing external Discord invite links is strictly prohibited in this outpost!`).then(msg => setTimeout(() => msg.delete().catch(()=>{}), 5000)).catch(()=>{});
                    return; 
                }
            }

            // Radar Kata Kasar
            if (!isViolating && !isCommand && badWords.length > 0) {
                const safeWords = badWords.map(w => w.trim().toLowerCase()).filter(w => w !== '');
                if (safeWords.some(word => contentLower.includes(word))) {
                    isViolating = true; message.delete().catch(()=>{}); sendAutoModLog('Triggered Word Filter', contentRaw);
                    message.channel.send(`⚠️ <@${message.author.id}>, Please, mind your language!`).then(msg => setTimeout(() => msg.delete().catch(()=>{}), 5000)).catch(()=>{});
                }
            }

            // Radar Link
            const linkRegex = /(https?:\/\/[^\s]+|www\.[^\s]+|discord\.gg\/[^\s]+)/gi;
            if (!isViolating && !isCommand && !isLinkAllowedChannel && linkRegex.test(contentLower) && !hasAdminPerm) {
                isViolating = true; message.delete().catch(()=>{}); sendAutoModLog('Posted a Link', contentRaw);
                message.channel.send(`🔗 <@${message.author.id}>, sending links is not allowed in this channel!`).then(msg => setTimeout(() => msg.delete().catch(()=>{}), 5000)).catch(()=>{});
            }

            // Radar Caps Lock
            if (!isViolating && !isCommand && contentRaw.length > 15 && !hasAdminPerm) {
                const capsCount = contentRaw.replace(/[^A-Z]/g, '').length;
                if ((capsCount / contentRaw.length) * 100 > 70) {
                    isViolating = true; message.delete().catch(()=>{}); sendAutoModLog('Excessive Caps Lock', contentRaw);
                    message.channel.send(`🔠 <@${message.author.id}>, please turn off your Caps Lock!`).then(msg => setTimeout(() => msg.delete().catch(()=>{}), 5000)).catch(()=>{});
                }
            }

            if (isViolating) return; 

            // ==========================================
            // 3. SISTEM RPG CHAT LEVELING (Fase 1)
            // ==========================================
            if (!isCommand) {
                const userId = message.author.id;
                
                // Cek apakah pemain sedang dalam masa cooldown (60 detik)
                if (!xpCooldowns.has(userId)) {
                    // Buat file/database jika belum ada
                    if (!fs.existsSync(profileFile)) fs.writeFileSync(profileFile, JSON.stringify({}, null, 4));
                    const db = JSON.parse(fs.readFileSync(profileFile, 'utf8'));
                    
                    if (!db[guildId]) db[guildId] = {};
                    if (!db[guildId][userId]) {
                        db[guildId][userId] = { xp: 0, level: 1, titles: [], badges: [], activeTitle: "New Explorer" };
                    }

                    // Berikan XP acak antara 15 sampai 25
                    const gainedXP = Math.floor(Math.random() * 11) + 15; 
                    db[guildId][userId].xp += gainedXP;

                    // Rumus Leveling (XP = Level^2 * 100) -> Level 2 butuh 400 total XP
                    const currentLevel = db[guildId][userId].level;
                    const nextLevelXP = currentLevel * currentLevel * 100;

                    // Jika XP mencukupi, naikkan level
                    if (db[guildId][userId].xp >= nextLevelXP) {
                        db[guildId][userId].level += 1;
                        
                        const levelUpEmbed = new EmbedBuilder()
                            .setColor('#F1C40F')
                            .setTitle('🎉 LEVEL UP!')
                            .setDescription(`Congratulations <@${userId}>!\nYou have reached **Level ${db[guildId][userId].level}**! Keep exploring the outpost.`)
                            .setThumbnail(message.author.displayAvatarURL({ dynamic: true }));

                        message.channel.send({ content: `<@${userId}>`, embeds: [levelUpEmbed] }).catch(()=>{});
                    }

                    // Simpan data dan masukkan pemain ke daftar cooldown
                    fs.writeFileSync(profileFile, JSON.stringify(db, null, 4));
                    xpCooldowns.add(userId);
                    
                    // Lepaskan cooldown setelah 60 detik (60000 ms)
                    setTimeout(() => {
                        xpCooldowns.delete(userId);
                    }, 60000);
                }
            }

            // ==========================================
            // 4. AFK SYSTEM & COMMAND EXECUTION
            // ==========================================
            let afkData = {};
            try { afkData = JSON.parse(fs.readFileSync(client.AFK_FILE, 'utf8')); } catch (e) {}
            let afkChanged = false;

            if (afkData[guildId] && afkData[guildId][message.author.id]) {
                delete afkData[guildId][message.author.id];
                afkChanged = true;
                message.channel.send(`👋 Welcome back **<@${message.author.id}>**, I removed your AFK.`).then(msg => setTimeout(() => msg.delete().catch(()=>{}), 5000));
            }

            if (message.mentions.users.size > 0 && afkData[guildId]) {
                message.mentions.users.forEach(user => {
                    if (afkData[guildId][user.id]) {
                        const afkInfo = afkData[guildId][user.id];
                        const timeAgo = Math.floor(afkInfo.timestamp / 1000);
                        message.channel.send(`💤 **${user.username}** is AFK: ${afkInfo.reason} *(since <t:${timeAgo}:R>)*`);
                    }
                });
            }

            if (afkChanged) fs.writeFileSync(client.AFK_FILE, JSON.stringify(afkData, null, 2));

            if (!contentLower.startsWith(client.PREFIX.toLowerCase())) return;
            const args = contentRaw.slice(client.PREFIX.length).trim().split(/\s+/);
            if (args.length === 0) return;

            const commandName = args.shift().toLowerCase();
            const command = client.commands.get(commandName);
            if (!command) return;

            const isRealAdmin = message.member?.permissions?.has(PermissionFlagsBits.ManageGuild) || false;
            const isCustomAdmin = settings[guildId].authorizedUsers.includes(message.author.id);

            message.reply = (content) => message.channel.send(content);
            try { await command.executePrefix(message, args, client.SETTINGS_FILE, settings, isRealAdmin, isCustomAdmin); }
            catch (error) { console.error(error); }

        } catch (error) { console.error("Critical Message Event Error:", error); }
    },
};
